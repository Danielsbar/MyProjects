#! /bin/bash

echo "$2" > $1
