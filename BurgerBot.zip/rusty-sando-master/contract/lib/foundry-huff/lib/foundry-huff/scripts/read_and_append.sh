#! /bin/bash

cat $2 >> $1
